//! DUET Benchmark Suite
//!
//! Criterion benchmark suite for the DUET crate.
//!
//! Baselines (named, not coded — a baseline means the same thing everywhere):
//!   no_kt        — No KT (zero-cost floor)
//!   single_index — log tree only, no prefix tree, no warning label
//!   dual_index   — prefix tree + log tree, no windowing
//!   windowed     — full proposal: dual-index + windowed consistency proofs
//!
//! Metrics (M1–M13, numbered in reading order:
//! size → latency → bandwidth → detection → scale → maintenance → modes):
//!   M1  — Proof size (bytes / hash count)
//!   M2  — Proof generation cost (ns)
//!   M3  — Proof verification cost (ns)
//!   M4  — Catch-up cost (proof size across W epochs)
//!   M5  — Marginal warning-slot lookup cost, an unverified read (ns)
//!         NOT detection latency: the detector does one or two proof-carrying
//!         lookups (the own slot always; the verifiably-empty warning slot only
//!         when the own slot still holds the expected key). See ch6 §"Warning-slot
//!         lookup cost". The CSV key M5_detection is a historical misnomer,
//!         kept only so the committed benchmark corpus stays addressable.
//!   M6  — False positive rate
//!   M7  — Scale verification (N = 10^6, 10^7; sizes, verify times, memory)
//!   M8  — Latency-derived single-thread operation rate (lookups/updates per second)
//!   M9  — Key rotation cost + epoch-commit cost vs N
//!   M10 — VRF isolation (prove / verify, constant-time)
//!   M11 — KT lookup-verification cost at the handshake hook (vs the no_kt baseline)
//!   M12 — Auditor cost: local signature + consistency-proof kernel; cross-vantage one-head fork check
//!   M13 — Session (dual-index) vs continuous (CEA) mode: per-epoch verify
//!         cost + directory write-count trade
//!
//! NOTE (2026 renumber): M1/M2/M3 and M7/M8 were reordered to match the
//! chapter's reading order (old M3→M1, M1→M2, M2→M3, M7↔M8); baseline codes
//! B1–B4 were retired in favour of the names above.
//!
//! SAMPLING RULE (no single-label artifacts): in the path-compressed sparse
//! tree, per-lookup cost is data-dependent — a proof whose co-path contains a
//! shallow compressed-leaf sibling pays up to ~256 extra hashes in
//! `subtree_hash`, so one label can cost ~1 µs and another ~50 µs at the same
//! N. The manual CSV distributions therefore cycle through a seeded sample of
//! labels (users or conversations) and report median/p95, the same methodology
//! M7 always used. No value written to results/*.csv — and so no figure the
//! thesis quotes — may hinge on one fixed label's path.
//!
//! SCOPE: the rule covers the manual CSV passes, not the Criterion passes
//! beside them. The only Criterion passes that still bench a fixed
//! representative label (`user-000000`) are M7_scale_verification's rigorous-CI
//! pass and the constant-time VRF group M10; their HTML reports are exploratory
//! and are not the committed corpus. M2 and M3's data-dependent Criterion loops
//! now cycle sampled labels, matching the CSV passes, and M12 times log-level
//! auditor operations rather than a per-label path. Sampling the two remaining
//! fixed passes too is a reasonable future revision, but it would orphan the
//! committed CSVs, so it is deliberately not done here.
//!
//! Machine-readable timings (median / p95 / mean / 95% CI half-width) for
//! M2/M3/M4/M5/M8/M9/M10/M11/M12/M13 are dumped to results/rust_benchmark_timings.csv
//! (complements Criterion's HTML CIs; for M4_catchup_gen the N column carries
//! the window W); M1/M4/M6 sizes/rates to
//! results/rust_benchmark_results.csv; M7 (scale, incl. full_client_verify) to
//! results/rust_benchmark_m7.csv; M13 write-counts to results/rust_benchmark_m13.csv.
//! EVERY timing quoted in thesis ch. 6 / appendix E must trace to a CSV row here.
//!
//! Run:
//!   cargo bench                          # full suite with HTML reports + CSV
//!   KT_SKIP_CSV=1 cargo bench -- "M2"    # just M2 timings, skip CSV regen
//!   KT_SKIP_CSV=1 cargo bench -- "M4"    # just M4 timings (windowed proofs)
//!
//! The CSV summary (M1 proof sizes incl. N=10^6, M4 catch-up grid, M6 FP rate)
//! is computed once per run and takes a few minutes (dominated by VRF
//! evaluations when building large servers).
//!
//! Results:
//!   target/criterion/          — HTML reports with graphs
//!   results/rust_benchmark_results.csv  — summary CSV for thesis

use criterion::{black_box, criterion_group, criterion_main, BenchmarkId, Criterion, Throughput};
use std::fs;
use std::io::Write;

use duet::auditor::Auditor;
use duet::dual_index::derive_dual_index_labels;
use duet::hashing::sha256;
use duet::merkle_log::MerkleLog;
use duet::prefix_tree::SparsePrefixTree;
use duet::server::{
    verify_raw_proof_unbound, verify_search_result, verify_search_result_raw_for, KTServer,
};
use duet::vrf::{generate_vrf_keypair, vrf_prove, vrf_verify};

const HASH_SIZE: usize = 32;
/// N values for tree-heavy benchmarks (proof generation/verification involve full tree traversal)
const N_VALUES_TREE: &[usize] = &[100, 1_000, 10_000];
/// N values for lightweight benchmarks (log-only, proof sizes)
const N_VALUES_LOG: &[usize] = &[100, 1_000, 10_000, 100_000];
const W_VALUES: &[usize] = &[1, 24, 168, 720];
/// N values for M1 proof-size computation (computed once, not timed).
/// Includes 10^6 for the headline comparison vs CONIKS (~1.2 kB at N=10^6).
/// N=10^6 takes a few minutes (one VRF evaluation per inserted label).
const N_VALUES_M1: &[usize] = &[100, 1_000, 10_000, 100_000, 1_000_000];
/// N grid for M4 catch-up CSV (windowed vs sequential bytes).
const N_VALUES_M4: &[usize] = &[1_000, 10_000, 100_000];

// ── Helpers ────────────────────────────────────────────────────

/// Fixed VRF seed so tree shapes / proof sizes are identical across runs
/// (reproducibility: fixed seed). Changing this changes M1 hash counts
/// by ±1 (random leaf depths).
const BENCH_VRF_SEED: [u8; 32] = [42u8; 32];

/// Build a server with N users in a single epoch.
fn build_server(n: usize) -> KTServer {
    let mut server = KTServer::from_seed(BENCH_VRF_SEED);
    // No benchmark that uses `build_server` runs a transition audit, so we
    // switch OFF per-epoch update-set recording here: at N = 10^7 keeping a
    // DeltaOp per user would add gigabytes on top of the already ~17 GB tree.
    // `build_server_epochs` (used by the auditor benchmark, M12) leaves
    // recording ON so its transition audit has the declared deltas.
    server.set_delta_recording(false);
    for i in 0..n {
        let user_id = format!("user-{:06}", i);
        let pk = sha256(user_id.as_bytes());
        server.update(user_id.as_bytes(), &pk);
    }
    server.commit_epoch();
    server
}

/// Build a server with N users spread across `epochs` epochs.
fn build_server_epochs(n: usize, epochs: usize) -> KTServer {
    let mut server = KTServer::from_seed(BENCH_VRF_SEED);
    let users_per_epoch = std::cmp::max(1, n / epochs);
    let mut counter = 0;

    for epoch in 0..epochs {
        // Last epoch absorbs the remainder so exactly n users are inserted
        // (previously n/epochs was floored: "N=1000, W=720" really had 730 users).
        let batch = if epoch == epochs - 1 {
            n.saturating_sub(counter)
        } else {
            std::cmp::min(users_per_epoch, n.saturating_sub(counter))
        };
        for _ in 0..batch {
            let uid = format!("user-{:06}", counter);
            server.update(uid.as_bytes(), &sha256(uid.as_bytes()));
            counter += 1;
        }
        server.commit_epoch();
    }
    server
}

/// A benchmark conversation: shared secret plus the two party identifiers.
struct BenchConversation {
    ss: [u8; 32],
    id_a: Vec<u8>,
    id_b: Vec<u8>,
}

/// Register `k` seed-deterministic conversations on `server` (both lookup
/// labels written; warning slots left clean) and return them. The caller
/// commits the epoch. Sampling many conversations — instead of one fixed
/// alice/bob pair — turns every label-position-dependent cost into a
/// distribution rather than a single-path artifact (see SAMPLING RULE in the
/// header): the same warning-slot read is ~1 µs on a typical path and up to
/// ~50 µs when a shallow compressed-leaf sibling forces a full 256-level
/// `subtree_hash` chain.
fn register_bench_conversations(server: &mut KTServer, k: usize) -> Vec<BenchConversation> {
    let mut convs = Vec::with_capacity(k);
    for i in 0..k {
        let ss = sha256(format!("bench-conv-ss-{:06}", i).as_bytes());
        // 16-byte fixed-width ids (dual-index derivation asserts the width).
        let id_a = format!("conv-a-{:09}", i).into_bytes();
        let id_b = format!("conv-b-{:09}", i).into_bytes();
        let la = derive_dual_index_labels(&ss, &id_a, &id_b);
        let lb = derive_dual_index_labels(&ss, &id_b, &id_a);
        server
            .update_raw(&la.label_lookup, &sha256(&id_a))
            .expect("bench: fresh lookup slot");
        server
            .update_raw(&lb.label_lookup, &sha256(&id_b))
            .expect("bench: fresh lookup slot");
        convs.push(BenchConversation { ss, id_a, id_b });
    }
    convs
}

/// Seeded sample of `k` registered user ids on a `build_server(n)` server
/// (ids are formatted `user-{:06}`; StdRng(42) mirrors M7's sampling).
fn sampled_user_ids(n: usize, k: usize) -> Vec<Vec<u8>> {
    use rand::{rngs::StdRng, Rng, SeedableRng};
    let mut rng = StdRng::seed_from_u64(42);
    (0..k)
        .map(|_| format!("user-{:06}", rng.gen_range(0..n)).into_bytes())
        .collect()
}

// ── M2: Proof Generation Cost ──────────────────────────────────

fn bench_m2_proof_generation(c: &mut Criterion) {
    let mut group = c.benchmark_group("M2_proof_generation");

    // single_index: Log inclusion proofs scale O(log N) — fast even at 100K.
    // Benchmarked against a Merkle tree with N leaves (single-index baseline);
    // previously this used a 1-epoch server log (1 leaf => trivial 4 ns proofs).
    group.sample_size(30);
    for &n in N_VALUES_LOG {
        let mut log = MerkleLog::new();
        for i in 0..n {
            let uid = format!("user-{:06}", i);
            log.append(&sha256(uid.as_bytes()));
        }
        group.bench_with_input(
            BenchmarkId::new("single_index_log_inclusion", n),
            &n,
            |b, _| {
                b.iter(|| black_box(log.inclusion_proof(0)));
            },
        );
    }

    // VRF-indexed lookup (search_by_user_id; frozen CSV id `dual_index`): full
    // search involves prefix tree traversal — O(N) with current impl.
    // Use fewer samples for large N. Cycles sampled users (SAMPLING RULE).
    group.sample_size(10);
    for &n in N_VALUES_TREE {
        let mut server = build_server(n);
        let uids = sampled_user_ids(n, 200);
        // Pre-warm: ensure root is cached
        let _ = server.search_by_user_id(&uids[0]);

        let idx = std::cell::Cell::new(0usize);
        group.bench_with_input(BenchmarkId::new("dual_index_full_search", n), &n, |b, _| {
            b.iter(|| {
                let i = idx.get();
                idx.set((i + 1) % uids.len());
                let r = server.search_by_user_id(&uids[i]);
                black_box(r.value);
            });
        });
    }

    // VRF evaluation alone (constant time, independent of N)
    group.sample_size(30);
    {
        let kp = generate_vrf_keypair();
        group.bench_function("VRF_prove_standalone", |b| {
            b.iter(|| {
                black_box(vrf_prove(&kp.secret, b"user-000000"));
            });
        });
    }

    group.finish();
}

// ── M3: Proof Verification Cost ────────────────────────────────

fn bench_m3_proof_verification(c: &mut Criterion) {
    let mut group = c.benchmark_group("M3_proof_verification");
    group.sample_size(30);

    for &n in N_VALUES_TREE {
        // single_index: Log inclusion proof verification against a Merkle tree with N
        // leaves (single-index baseline). Previously verified a 1-leaf log
        // (empty path => ~60 ns no-op verification).
        {
            let mut log = MerkleLog::new();
            for i in 0..n {
                let uid = format!("user-{:06}", i);
                log.append(&sha256(uid.as_bytes()));
            }
            let proof = log.inclusion_proof(0);
            let root = log.root_hash();
            let leaf = sha256(b"user-000000");

            group.bench_with_input(
                BenchmarkId::new("single_index_log_inclusion_verify", n),
                &n,
                |b, _| {
                    b.iter(|| {
                        black_box(MerkleLog::verify_inclusion(&leaf, &proof, &root));
                    });
                },
            );
        }

        // dual-index: VRF proof verification (constant time, but included for completeness)
        {
            let mut server = build_server(n);
            let result = server.search_by_user_id(b"user-000000");
            let vrf_proof = result.vrf_proof.unwrap();
            let pk = server.vrf_public_key().clone();

            group.bench_with_input(BenchmarkId::new("dual_index_vrf_verify", n), &n, |b, _| {
                b.iter(|| {
                    black_box(vrf_verify(&pk, b"user-000000", &vrf_proof).unwrap());
                });
            });
        }

        // dual-index: prefix proof verification = the client's real operation:
        // recompute the root from the proof alone (no trusted input),
        // then the root is checked via log inclusion (timed separately
        // and together in windowed_full_client_verify below).
        //
        // NB: "windowed" in these ids is the BASELINE name (the full scheme:
        // dual-index + windowed consistency), not a claim that this times a
        // windowed catch-up proof. M3 times the full signed-head LOOKUP
        // verification; the windowed catch-up proof itself is M4. The CSV key
        // (M3_full_client_verify) is kept for corpus stability.
        {
            let mut server = build_server(n);
            let uids = sampled_user_ids(n, 200);
            let proofs: Vec<_> = uids
                .iter()
                .map(|u| {
                    let result = server.search_by_user_id(u);
                    // Sanity: the full chain must hold before we time pieces of it.
                    verify_raw_proof_unbound(&result)
                        .expect("search result must verify (prefix root in log)");
                    result.prefix_proof
                })
                .collect();

            let idx = std::cell::Cell::new(0usize);
            group.bench_with_input(
                BenchmarkId::new("dual_index_prefix_verify", n),
                &n,
                |b, _| {
                    b.iter(|| {
                        let i = idx.get();
                        idx.set((i + 1) % proofs.len());
                        black_box(SparsePrefixTree::recompute_root(&proofs[i]));
                    });
                },
            );
        }

        // windowed: full signed-head lookup verification — the headline client-side number:
        // VRF verify + label binding + prefix-root recompute + log
        // inclusion + STH signature (P1 + P2 complete chain).
        {
            let mut server = build_server(n);
            let sth = server.commit_epoch(); // fresh STH matching the head
            let pk = server.vrf_public_key().clone();
            let vk = server.sth_verifying_key();
            assert!(sth.verify(&vk), "STH signature must verify");
            let uids = sampled_user_ids(n, 200);
            let results: Vec<_> = uids
                .iter()
                .map(|u| {
                    let result = server.search_by_user_id(u);
                    assert_eq!(result.tree_head, sth.root, "STH must match search head");
                    verify_search_result(&pk, u, &result).expect("full chain must verify");
                    result
                })
                .collect();

            let idx = std::cell::Cell::new(0usize);
            group.bench_with_input(
                BenchmarkId::new("windowed_full_client_verify", n),
                &n,
                |b, _| {
                    b.iter(|| {
                        let i = idx.get();
                        idx.set((i + 1) % results.len());
                        let root =
                            verify_search_result(&pk, &uids[i], &results[i]).expect("verifies");
                        black_box(root);
                        black_box(sth.verify(&vk));
                    });
                },
            );
        }

        // windowed: Consistency proof verification.
        // old_root must be the root at the size the client last saw
        // (previously both roots were the current root, so the timed
        // verification always returned false).
        {
            let total_epochs = 50;
            let server = build_server_epochs(n, total_epochs);
            let from: u64 = 10;
            let proof = server.windowed_consistency_proof(from);
            let old_root = server.log_root_at(from as usize);
            let new_root = server.log_root();
            assert!(
                MerkleLog::verify_consistency(&proof, &old_root, &new_root),
                "consistency proof must verify with correct roots"
            );

            group.bench_with_input(
                BenchmarkId::new("windowed_consistency_verify", n),
                &n,
                |b, _| {
                    b.iter(|| {
                        black_box(MerkleLog::verify_consistency(&proof, &old_root, &new_root));
                    });
                },
            );
        }
    }

    group.finish();
}

// ── M1: Proof Size (computed, not timed) ───────────────────────

fn compute_proof_sizes() -> Vec<(String, usize, usize, String)> {
    // Returns: (baseline, parameter, value, unit)
    let mut rows = Vec::new();

    for &n in N_VALUES_M1 {
        eprintln!("M1: computing proof sizes at N={} ...", n);

        // single_index (single-index, log only): a Merkle tree over N user entries,
        // lookup proof = inclusion proof for one leaf => ~ceil(lg N) hashes.
        // (Previously this took inclusion_proof(0) from a 1-epoch server log,
        //  i.e. a 1-leaf tree => empty path => the bogus "0 bytes" rows.)
        let mut b2_log = MerkleLog::new();
        for i in 0..n {
            let uid = format!("user-{:06}", i);
            b2_log.append(&sha256(uid.as_bytes()));
        }
        let b2_proof = b2_log.inclusion_proof(0);
        let b2_bytes = b2_proof.path.len() * HASH_SIZE;
        let b2_hashes = b2_proof.path.len();
        rows.push(("single_index".into(), n, b2_bytes, "bytes".into()));
        rows.push(("single_index_hashes".into(), n, b2_hashes, "hashes".into()));

        // VRF-indexed lookup (search_by_user_id): prefix proof + VRF proof + log
        // inclusion. Emitted under the historical CSV row id `dual_index` (kept
        // stable for downstream tooling); it measures the VRF-indexed path the
        // client runs, NOT the raw dual-index search(label) path, which carries
        // no VRF proof and is correspondingly smaller.
        // The server log here has 1 epoch leaf, so its inclusion component is
        // 0 bytes; report the epoch-log inclusion separately from the realistic
        // multi-epoch case (M4 covers consistency across epochs).
        let mut server_b3 = build_server(n);
        let result = server_b3.search_by_user_id(b"user-000000");
        let prefix_bytes = result.prefix_proof.size_bytes();
        let vrf_bytes = 80; // ECVRF-EDWARDS25519-SHA512-TAI proof is always 80 bytes
        let log_incl_bytes = server_b3.inclusion_proof(0).path.len() * HASH_SIZE;
        let b3_bytes = prefix_bytes + log_incl_bytes + vrf_bytes;
        rows.push(("dual_index".into(), n, b3_bytes, "bytes".into()));
        rows.push((
            "dual_index_prefix_hashes".into(),
            n,
            result.prefix_proof.num_siblings(),
            "hashes".into(),
        ));
    }

    rows
}

// ── M4: Catch-Up Cost ──────────────────────────────────────────

fn bench_m4_catchup_cost(c: &mut Criterion) {
    let mut group = c.benchmark_group("M4_catchup_cost");
    group.sample_size(20);

    let n = 1_000;

    for &w in W_VALUES {
        let total_epochs = w + 10;
        let server = build_server_epochs(n, total_epochs);
        let from_epoch = (total_epochs - w) as u64;

        // dual_index: Sequential — W individual proofs (no windowing)
        group.bench_with_input(BenchmarkId::new("sequential", w), &w, |b, &w| {
            b.iter(|| {
                for e in 0..w {
                    let from = (from_epoch as usize) + e;
                    if from < server.log_size() {
                        black_box(server.windowed_consistency_proof(from as u64));
                    }
                }
            });
        });

        // windowed: Single windowed consistency proof
        group.bench_with_input(BenchmarkId::new("windowed", w), &w, |b, _| {
            b.iter(|| {
                black_box(server.windowed_consistency_proof(from_epoch));
            });
        });
    }

    group.finish();
}

// ── M5: Marginal warning-slot lookup cost (NOT detection latency) ──
//
// DUET dual-index warning check (thesis Algorithm 6). The dual-index warning is
// DUET's own contribution, not ACKA's; after a proof-verified mismatch an honest
// endpoint (not the attacker) writes the shared warning slot:
//
//   The warning label l_warn = HKDF-Expand(PRK, "warning" || min(id) || max(id)),
//   with PRK = HKDF-Extract(salt, S), is a sentinel slot (see dual_index.rs).
//   In normal operation nobody writes to it → search returns None.
//
//   The attack-state benchmark pre-populates the warning slot to model an
//   alert already published there by the honest endpoint that detected the
//   substitution; an attacker holding a different shared secret derives
//   disjoint labels and cannot reach this slot.
//   search(W) → is_some() is the SIGNAL, not the detector. The real detector
//   (kt_client.detectMitm) proof-verifies one or two lookups: the client's own
//   slot must verifiably still hold its key, and on the clean path, where it does,
//   the warning slot must additionally be verifiably
//   EMPTY (a non-inclusion proof — an unproven "empty" lets the server censor
//   the warning). What follows times neither: it times the marginal unverified
//   read, in clean state, which is why it lands in microseconds.
//
//   Clean case:   warning label empty     → no alarm
//   Attack case:  warning label populated → MitM detected
//
// What we time:  derive_dual_index_labels + search(warning_label).is_some()
//                NOTE: this is the *marginal* cost of the warning-slot read on
//                top of an already-verified lookup; it is an unverified read and
//                does not itself check a proof. The security-bearing detection
//                cost is one or two full verified lookups; M3 times the
//                VRF-indexed chain and stands as a conservative local proxy for
//                one raw-label verification, not a formal upper bound.

fn bench_m5_mitm_detection(c: &mut Criterion) {
    let mut group = c.benchmark_group("M5_mitm_detection");
    group.sample_size(30);

    for &n in &[100, 1_000, 10_000] {
        // ── Build server with N background users + K sampled conversations ──
        // K scales with N so conversation labels do not dominate a small tree.
        // Each timed iteration uses the NEXT sampled conversation, so the
        // statistics cover many warning-label positions instead of hinging on
        // one label's proof path (SAMPLING RULE; the old single alice/bob pair
        // read 1.4 µs or ~50 µs depending on where the fixed label happened
        // to land).
        let k = n.clamp(100, 1_000);
        let mut server = build_server(n);
        let convs = register_bench_conversations(&mut server, k);
        // Warning labels are NOT written — clean state
        server.commit_epoch();

        // ── Clean case: search warning label → None → no alarm ──
        let idx = std::cell::Cell::new(0usize);
        group.bench_with_input(BenchmarkId::new("dual_index_clean", n), &n, |b, _| {
            b.iter(|| {
                let i = idx.get();
                idx.set((i + 1) % convs.len());
                let cv = &convs[i];
                let labels = derive_dual_index_labels(&cv.ss, &cv.id_a, &cv.id_b);
                let w = server.search(&labels.label_warning);
                // Detection: is_some() means attack
                let alarm = w.value.is_some();
                black_box(alarm);
            });
        });

        // ── Attack case: MitM populates every sampled warning label ──
        // Simulate: MitM performed a separate key exchange, causing an entry
        // to appear at each victim's warning label.
        for cv in &convs {
            let labels = derive_dual_index_labels(&cv.ss, &cv.id_a, &cv.id_b);
            server
                .update_raw(&labels.label_warning, &[0x01])
                .expect("bench: fresh warning slot");
        }
        server.commit_epoch();

        let idx = std::cell::Cell::new(0usize);
        group.bench_with_input(
            BenchmarkId::new("dual_index_mitm_detected", n),
            &n,
            |b, _| {
                b.iter(|| {
                    let i = idx.get();
                    idx.set((i + 1) % convs.len());
                    let cv = &convs[i];
                    let labels = derive_dual_index_labels(&cv.ss, &cv.id_a, &cv.id_b);
                    let w = server.search(&labels.label_warning);
                    // Detection: is_some() means attack → true here
                    let alarm = w.value.is_some();
                    black_box(alarm);
                });
            },
        );
    }

    group.finish();
}

// ── M7a: Verification at CONIKS scale (N = 10^6, 10^7) ─────────
//
// CONIKS reports 159 µs authentication-path verification at N = 10^7
// (2 GHz Core i7, [Melara et al. §5.3]). This group measures our client-side
// verification and server-side proof generation at the same scale, so the
// thesis comparison is apples-to-apples instead of 10^4-vs-10^7.
//
// Methodology notes (report these alongside the numbers):
//   * single-machine, IN-MEMORY server: no network round-trips, no
//     persistent DB — not directly comparable to Parakeet/SEEMless
//     (their epoch costs are DB-write-bound)
//   * single-epoch log (E = 1): a deployed lookup proof additionally
//     carries the log-inclusion path, +32·⌈lg E⌉ bytes
//   * memory row is RSS *after* build (sysinfo), not the true peak
//   * depth / latency / size rows are median + p95 (+ max for depth/size)
//     over KT_BENCH_M7_SAMPLES (default 1000) users sampled uniformly with
//     seeded StdRng(42) — NOT a single hand-picked lookup
//   * environment recorded automatically to results/BENCH_ENVIRONMENT.md
//
// Gated behind an env var because building the 10^7 server performs one
// VRF evaluation per user (~107 µs each => ~20 min) and needs a few GB RAM:
//
//   KT_BENCH_LARGE_N=1 KT_SKIP_CSV=1 cargo bench -- M7
//
// Smoke test / grid override:
//   KT_BENCH_LARGE_N=1 KT_BENCH_M7_NS=10000 KT_BENCH_M7_SAMPLES=100 \
//     KT_SKIP_CSV=1 cargo bench -- M7
//
// All rows are written to results/rust_benchmark_m7.csv.

/// Sort a vector of f64 ascending (for percentile extraction).
fn sorted(mut v: Vec<f64>) -> Vec<f64> {
    v.sort_by(|a, b| a.partial_cmp(b).unwrap());
    v
}

/// Nearest-rank percentile of an ascending-sorted slice (p in [0,1]).
fn percentile(sorted_v: &[f64], p: f64) -> f64 {
    if sorted_v.is_empty() {
        return f64::NAN;
    }
    let idx = ((sorted_v.len() as f64 - 1.0) * p).round() as usize;
    sorted_v[idx]
}

/// Resident set size of this process in MB (RSS now — not peak).
fn rss_mb() -> f64 {
    let mut sys = sysinfo::System::new();
    match sysinfo::get_current_pid() {
        Ok(pid) => {
            sys.refresh_process(pid);
            sys.process(pid)
                .map(|p| p.memory() as f64 / (1024.0 * 1024.0))
                .unwrap_or(f64::NAN)
        }
        Err(_) => f64::NAN,
    }
}

/// Auto-record the benchmark environment (B.2.6 / BENCH_ENVIRONMENT.md).
/// Print the git HEAD at the start of each phase so the console transcript
/// is self-documenting about exactly which commit produced which artifact
/// (the environment file records HEAD once; this pins it per phase).
fn print_phase_head(phase: &str) {
    use std::process::Command;
    let head = Command::new("git")
        .args(["rev-parse", "--short", "HEAD"])
        .output()
        .ok()
        .and_then(|o| String::from_utf8(o.stdout).ok())
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty())
        .unwrap_or_else(|| "unknown".into());
    eprintln!("[{}] git HEAD = {}", phase, head);
}

fn write_bench_environment() {
    use std::process::Command;
    let run = |cmd: &str, args: &[&str]| -> String {
        Command::new(cmd)
            .args(args)
            .output()
            .ok()
            .and_then(|o| String::from_utf8(o.stdout).ok())
            .map(|s| s.trim().to_string())
            .filter(|s| !s.is_empty())
            .unwrap_or_else(|| "unknown".into())
    };
    let mut sys = sysinfo::System::new();
    sys.refresh_cpu();
    sys.refresh_memory();
    let cpu = sys
        .cpus()
        .first()
        .map(|c| c.brand().trim().to_string())
        .unwrap_or_else(|| "unknown".into());
    let ram_gb = sys.total_memory() as f64 / (1024.0 * 1024.0 * 1024.0);
    let cores = std::thread::available_parallelism()
        .map(|x| x.get())
        .unwrap_or(0);
    let epoch_s = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);

    let _ = fs::create_dir_all("results");
    let mut f = fs::File::create("results/BENCH_ENVIRONMENT.md").unwrap();
    writeln!(f, "# Benchmark environment (auto-generated by kt_bench M7)").unwrap();
    writeln!(f, "- run timestamp (unix seconds, UTC): {}", epoch_s).unwrap();
    writeln!(
        f,
        "- OS / arch: {} / {}",
        std::env::consts::OS,
        std::env::consts::ARCH
    )
    .unwrap();
    writeln!(f, "- CPU: {} ({} logical cores)", cpu, cores).unwrap();
    // sha2 dispatches to SHA-NI at runtime where available; without it the
    // SHA-bound metrics (M3 prefix/full verify, M5, M8 update, M9, M13) take a
    // software path for every hash and run materially slower, while the
    // VRF-bound metrics are largely unaffected. A run is therefore not
    // comparable to one on a host that differs here -- pinning rustc does not
    // make the numbers portable.
    #[cfg(any(target_arch = "x86", target_arch = "x86_64"))]
    let sha_ni = if std::is_x86_feature_detected!("sha") {
        "yes (hardware SHA-256)"
    } else {
        "no (software SHA-256 fallback)"
    };
    #[cfg(not(any(target_arch = "x86", target_arch = "x86_64")))]
    let sha_ni = "unknown (non-x86 host)";
    writeln!(f, "- CPU SHA extensions (SHA-NI): {}", sha_ni).unwrap();
    writeln!(f, "- RAM: {:.1} GB", ram_gb).unwrap();
    writeln!(f, "- rustc: {}", run("rustc", &["--version"])).unwrap();
    writeln!(f, "- cargo: {}", run("cargo", &["--version"])).unwrap();
    writeln!(
        f,
        "- git commit: {}",
        run("git", &["rev-parse", "--short", "HEAD"])
    )
    .unwrap();
    writeln!(
        f,
        "- profile: bench (opt-level 3); benchmark loops single-threaded"
    )
    .unwrap();
    writeln!(
        f,
        "- methodology caveats: in-memory server (no network, no DB);"
    )
    .unwrap();
    writeln!(
        f,
        "  single-epoch log (E=1, deployed proofs add 32*ceil(lg E) B);"
    )
    .unwrap();
    writeln!(
        f,
        "  memory = RSS after build, not peak; VRF seed fixed [42;32];"
    )
    .unwrap();
    writeln!(f, "  lookup sampling StdRng seed 42.").unwrap();
}

fn bench_m7_scale_verification(c: &mut Criterion) {
    print_phase_head("M7 scale");
    if !std::env::var("KT_BENCH_LARGE_N")
        .map(|v| v == "1")
        .unwrap_or(false)
    {
        eprintln!("M7: skipped (set KT_BENCH_LARGE_N=1 to run; ~25 min total build time)");
        return;
    }

    use rand::{rngs::StdRng, Rng, SeedableRng};

    // N grid and per-N sample count, overridable for smoke tests.
    let ns: Vec<usize> = std::env::var("KT_BENCH_M7_NS")
        .ok()
        .map(|s| s.split(',').filter_map(|x| x.trim().parse().ok()).collect())
        .filter(|v: &Vec<usize>| !v.is_empty())
        .unwrap_or_else(|| vec![1_000_000, 10_000_000]);
    let samples: usize = std::env::var("KT_BENCH_M7_SAMPLES")
        .ok()
        .and_then(|s| s.parse().ok())
        .unwrap_or(1_000);

    let mut group = c.benchmark_group("M7_scale_verification");
    group.sample_size(20);

    let _ = fs::create_dir_all("results");
    write_bench_environment();
    let mut csv = fs::File::create("results/rust_benchmark_m7.csv").unwrap();
    writeln!(csv, "metric,baseline,N,W,value,unit").unwrap();

    for &n in &ns {
        eprintln!(
            "M7: building server with N={} (one VRF eval per user; ~{} min) ...",
            n,
            n / 500_000
        );
        let t0 = std::time::Instant::now();
        let mut server = build_server(n);
        let build_s = t0.elapsed().as_secs_f64();
        let rss = rss_mb();
        eprintln!(
            "M7: build took {:.1} s; RSS after build {:.0} MB",
            build_s, rss
        );
        writeln!(csv, "M7,build_time,{},-,{:.1},seconds", n, build_s).unwrap();
        writeln!(csv, "M7,rss_after_build,{},-,{:.0},MB", n, rss).unwrap();

        // ── Distribution pass: `samples` uniformly random users (seeded) ──
        // Median/p95/max over many lookups: sample users from the seeded
        // distribution rather than a single fixed favourable path.
        let vrf_pk = server.vrf_public_key().clone();
        let mut rng = StdRng::seed_from_u64(42);
        let mut depths: Vec<f64> = Vec::with_capacity(samples);
        let mut sizes: Vec<f64> = Vec::with_capacity(samples);
        let mut t_search: Vec<f64> = Vec::with_capacity(samples);
        let mut t_prefix: Vec<f64> = Vec::with_capacity(samples);
        let mut t_vrf: Vec<f64> = Vec::with_capacity(samples);

        for _ in 0..samples {
            // build_server() inserts ids formatted "user-{:06}"; reuse exactly.
            let uid = format!("user-{:06}", rng.gen_range(0..n));

            let t = std::time::Instant::now();
            let r = server.search_by_user_id(uid.as_bytes());
            t_search.push(t.elapsed().as_secs_f64() * 1e6);

            let t = std::time::Instant::now();
            let root = SparsePrefixTree::recompute_root(&r.prefix_proof);
            t_prefix.push(t.elapsed().as_secs_f64() * 1e6);
            assert!(
                root.is_some(),
                "prefix proof must reconstruct (N={}, uid={})",
                n,
                uid
            );
            // Untimed: assert the FULL chain (root inclusion in log) holds.
            verify_raw_proof_unbound(&r)
                .unwrap_or_else(|e| panic!("chain must verify (N={}, uid={}): {}", n, uid, e));

            let vp = r.vrf_proof.expect("search result carries VRF proof");
            let t = std::time::Instant::now();
            let vr = vrf_verify(&vrf_pk, uid.as_bytes(), &vp);
            t_vrf.push(t.elapsed().as_secs_f64() * 1e6);
            assert!(vr.is_ok(), "VRF proof must verify (N={}, uid={})", n, uid);

            depths.push(r.prefix_proof.num_siblings() as f64);
            // +80 B ECVRF proof; log-inclusion adds 32*ceil(lg E) B in deployment.
            sizes.push((r.prefix_proof.size_bytes() + 80) as f64);
        }

        let depths = sorted(depths);
        let sizes = sorted(sizes);
        let t_search = sorted(t_search);
        let t_prefix = sorted(t_prefix);
        let t_vrf = sorted(t_vrf);
        let depth_mean = depths.iter().sum::<f64>() / depths.len() as f64;

        writeln!(
            csv,
            "M7,depth_median,{},-,{:.0},hashes",
            n,
            percentile(&depths, 0.5)
        )
        .unwrap();
        writeln!(csv, "M7,depth_mean,{},-,{:.2},hashes", n, depth_mean).unwrap();
        writeln!(
            csv,
            "M7,depth_max,{},-,{:.0},hashes",
            n,
            depths.last().unwrap()
        )
        .unwrap();
        writeln!(
            csv,
            "M7,dual_index_lookup_bytes_median,{},-,{:.0},bytes",
            n,
            percentile(&sizes, 0.5)
        )
        .unwrap();
        writeln!(
            csv,
            "M7,dual_index_lookup_bytes_max,{},-,{:.0},bytes",
            n,
            sizes.last().unwrap()
        )
        .unwrap();
        writeln!(
            csv,
            "M7,full_search_median,{},-,{:.1},us",
            n,
            percentile(&t_search, 0.5)
        )
        .unwrap();
        writeln!(
            csv,
            "M7,full_search_p95,{},-,{:.1},us",
            n,
            percentile(&t_search, 0.95)
        )
        .unwrap();
        writeln!(
            csv,
            "M7,prefix_verify_median,{},-,{:.1},us",
            n,
            percentile(&t_prefix, 0.5)
        )
        .unwrap();
        writeln!(
            csv,
            "M7,prefix_verify_p95,{},-,{:.1},us",
            n,
            percentile(&t_prefix, 0.95)
        )
        .unwrap();
        writeln!(
            csv,
            "M7,vrf_verify_median,{},-,{:.1},us",
            n,
            percentile(&t_vrf, 0.5)
        )
        .unwrap();
        writeln!(
            csv,
            "M7,vrf_verify_p95,{},-,{:.1},us",
            n,
            percentile(&t_vrf, 0.95)
        )
        .unwrap();
        writeln!(csv, "M7,sample_count,{},-,{},lookups", n, samples).unwrap();

        // ── Criterion pass: fixed representative target (rigorous CI) ──
        // TWO POPULATIONS, do not conflate: the CSV M7 median/p95 above are a
        // DISTRIBUTION over sampled users (proof sizes vary with tree shape),
        // whereas the Criterion benches below time a SINGLE fixed user
        // ("user-000000") repeated for a tight steady-state estimate. Report
        // the CSV distribution as the headline M7 number; the Criterion figure
        // is a low-variance point measurement, not a population statistic.
        // Fresh commit so we hold an STH matching the served tree head.
        let sth = server.commit_epoch();
        let sth_vk = server.sth_verifying_key();
        let result = server.search_by_user_id(b"user-000000");
        let prefix_proof = result.prefix_proof.clone();
        let vrf_proof = result.vrf_proof.unwrap();
        assert_eq!(result.tree_head, sth.root, "STH must match search head");
        verify_search_result(&vrf_pk, b"user-000000", &result)
            .expect("full chain must verify at scale");
        assert!(sth.verify(&sth_vk), "STH signature must verify");

        // ── Distribution pass: full signed-head lookup verification (VRF + label binding +
        // prefix root + log inclusion + STH signature) over sampled users
        // (same SAMPLING RULE and seed as the pass above), so the headline
        // M7 metric is recorded in the CSV directly rather than existing
        // only as a Criterion estimate. Searches are untimed; the timed
        // body matches M3_full_client_verify's composition exactly.
        {
            let mut rng = StdRng::seed_from_u64(42);
            let mut t_full: Vec<f64> = Vec::with_capacity(samples);
            for _ in 0..samples {
                let uid = format!("user-{:06}", rng.gen_range(0..n));
                let r = server.search_by_user_id(uid.as_bytes());
                let t = std::time::Instant::now();
                verify_search_result(&vrf_pk, uid.as_bytes(), &r).unwrap_or_else(|e| {
                    panic!("full chain must verify (N={}, uid={}): {}", n, uid, e)
                });
                black_box(sth.verify(&sth_vk));
                t_full.push(t.elapsed().as_secs_f64() * 1e6);
            }
            let t_full = sorted(t_full);
            writeln!(
                csv,
                "M7,full_client_verify_median,{},-,{:.1},us",
                n,
                percentile(&t_full, 0.5)
            )
            .unwrap();
            writeln!(
                csv,
                "M7,full_client_verify_p95,{},-,{:.1},us",
                n,
                percentile(&t_full, 0.95)
            )
            .unwrap();
        }

        // Client-side: prefix proof verification (compare CONIKS 159 µs at 10^7)
        group.bench_with_input(
            BenchmarkId::new("dual_index_prefix_verify", n),
            &n,
            |b, _| {
                b.iter(|| {
                    black_box(SparsePrefixTree::recompute_root(&prefix_proof));
                });
            },
        );

        // Client-side: FULL verify (VRF + label binding + prefix root +
        // log inclusion + STH signature) — the apples-to-apples number
        // against CONIKS's 159 µs path + ~400 µs signature at N=10^7.
        // Single fixed user (steady-state point estimate); the population-level
        // M7 figure is the CSV full_client_verify_{median,p95} above.
        group.bench_with_input(
            BenchmarkId::new("windowed_full_client_verify", n),
            &n,
            |b, _| {
                b.iter(|| {
                    let root =
                        verify_search_result(&vrf_pk, b"user-000000", &result).expect("verifies");
                    black_box(root);
                    black_box(sth.verify(&sth_vk));
                });
            },
        );

        // Client-side: VRF proof verification (compare CONIKS ~400 µs sig verify)
        group.bench_with_input(BenchmarkId::new("dual_index_vrf_verify", n), &n, |b, _| {
            b.iter(|| {
                black_box(vrf_verify(&vrf_pk, b"user-000000", &vrf_proof).unwrap());
            });
        });

        // Server-side: full lookup (VRF prove + prefix search + proof assembly)
        group.bench_with_input(BenchmarkId::new("dual_index_full_search", n), &n, |b, _| {
            b.iter(|| {
                let r = server.search_by_user_id(b"user-000000");
                black_box(r.value);
            });
        });

        drop(server); // free several GB before building the next size
    }

    group.finish();
    eprintln!("M7 rows written to results/rust_benchmark_m7.csv; environment to results/BENCH_ENVIRONMENT.md");
}

// ── M6: False Positive Rate (computed, not timed) ──────────────
//
// A false positive = detection fires when there is NO MitM.
// We set up 1000 clean sessions where both parties share the same S,
// register only lookup labels (warning label left empty), then check:
//   search(warning_label).is_some() should be false.
// If it's true → false positive.

fn compute_false_positive_rate() -> f64 {
    let trials = 1_000;
    let mut false_positives = 0u32;

    for i in 0..trials {
        let mut server = KTServer::new();

        // Clean key exchange: same shared secret for both parties
        let shared_secret = sha256(format!("shared-{}", i).as_bytes());
        // 16-byte fixed-width ids (dual-index derivation asserts the width).
        let alice_id = format!("alice-{:010}", i);
        let bob_id = format!("bob-{:012}", i);

        let alice_labels =
            derive_dual_index_labels(&shared_secret, alice_id.as_bytes(), bob_id.as_bytes());
        let bob_labels =
            derive_dual_index_labels(&shared_secret, bob_id.as_bytes(), alice_id.as_bytes());

        // Register lookup labels only — warning label stays empty
        server
            .update_raw(&alice_labels.label_lookup, &sha256(alice_id.as_bytes()))
            .expect("bench: fresh lookup slot");
        server
            .update_raw(&bob_labels.label_lookup, &sha256(bob_id.as_bytes()))
            .expect("bench: fresh lookup slot");
        server.commit_epoch();

        // Check: warning label should be empty (no attack)
        let warning = server.search(&alice_labels.label_warning);
        if warning.value.is_some() {
            false_positives += 1;
        }
    }

    false_positives as f64 / trials as f64
}

// ── CSV Summary ────────────────────────────────────────────────

/// Computes M1/M4/M6 and writes the summary CSV exactly once.
///
/// NOTE: deliberately NOT wrapped in a Criterion benchmark — these are
/// computed quantities (proof sizes, rates), not timings, and re-running
/// them inside `b.iter()` multiplied the cost by the sample count
/// (prohibitive once N=10^6 is in the M1 grid).
fn write_csv(_c: &mut Criterion) {
    // Allow skipping the (multi-minute) CSV regeneration when running
    // filtered timing benchmarks, e.g.:  KT_SKIP_CSV=1 cargo bench -- M2
    if std::env::var("KT_SKIP_CSV")
        .map(|v| v == "1")
        .unwrap_or(false)
    {
        eprintln!("KT_SKIP_CSV=1 — skipping CSV summary generation");
        return;
    }

    print_phase_head("sizes CSV");
    let _ = fs::create_dir_all("results");
    let mut f = fs::File::create("results/rust_benchmark_results.csv").unwrap();
    writeln!(f, "metric,baseline,N,W,value,unit").unwrap();

    // M1: Proof sizes (W not applicable => "-"; 6 fields, matching the header)
    for (baseline, n, val, unit) in compute_proof_sizes() {
        writeln!(f, "M1,{},{},-,{},{}", baseline, n, val, unit).unwrap();
    }

    // M4: Catch-up bytes, windowed (windowed) vs naive sequential (dual_index), over an N grid
    for &n_m4 in N_VALUES_M4 {
        for &w in W_VALUES {
            eprintln!("M4: computing catch-up bytes at N={}, W={} ...", n_m4, w);
            let total = w + 10;
            let server = build_server_epochs(n_m4, total);
            let from = (total - w) as u64;

            // dual_index: sum of W individual proofs
            let mut b3_bytes = 0usize;
            for e in 0..w {
                let epoch = (from as usize) + e;
                if epoch < server.log_size() {
                    let p = server.windowed_consistency_proof(epoch as u64);
                    b3_bytes += p.path.len() * HASH_SIZE;
                }
            }
            writeln!(f, "M4,sequential,{},{},{},bytes", n_m4, w, b3_bytes).unwrap();

            // windowed: single windowed proof
            let p = server.windowed_consistency_proof(from);
            let b4_bytes = p.path.len() * HASH_SIZE;
            writeln!(f, "M4,windowed,{},{},{},bytes", n_m4, w, b4_bytes).unwrap();

            // Ratio
            let ratio = if b4_bytes > 0 {
                b3_bytes as f64 / b4_bytes as f64
            } else {
                0.0
            };
            writeln!(f, "M4,ratio,{},{},{:.2},x", n_m4, w, ratio).unwrap();
        }
    }

    // M6: False positive rate
    let fp = compute_false_positive_rate();
    writeln!(f, "M6,all,all,all,{},rate", fp).unwrap();

    eprintln!("CSV written to results/rust_benchmark_results.csv");
    black_box(());
}

// ── M8: Latency-derived single-thread operation rate ───────────
//
// Caveat: single-machine, single-threaded, in-memory —
// this is *per-op throughput*, not parallel scaling. Criterion's
// Throughput::Elements makes the report read in elements/second.

fn bench_m8_throughput(c: &mut Criterion) {
    let mut g = c.benchmark_group("M8_throughput");

    // Lookup throughput: full search at a fixed N (server side).
    let mut server = build_server(10_000);
    g.throughput(Throughput::Elements(1));
    let uids = sampled_user_ids(10_000, 200);
    let idx = std::cell::Cell::new(0usize);
    g.bench_function("dual_index_lookup_per_op_N10k", |b| {
        b.iter(|| {
            let i = idx.get();
            idx.set((i + 1) % uids.len());
            let r = server.search_by_user_id(&uids[i]);
            black_box(r.value);
        });
    });

    // Update throughput: insert UNIQUE keys (the tree grows; each update is
    // O(depth)). Interior mutability so the closure can be Fn.
    let serv = std::cell::RefCell::new(build_server(1_000));
    let ctr = std::cell::Cell::new(1_000usize);
    g.throughput(Throughput::Elements(1));
    g.bench_function("dual_index_update_per_op", |b| {
        b.iter(|| {
            let i = ctr.get();
            ctr.set(i + 1);
            let uid = format!("upd-{:08}", i);
            serv.borrow_mut()
                .update(uid.as_bytes(), &sha256(uid.as_bytes()));
        });
    });

    g.finish();
}

// ── M9: Key rotation cost ──────────────────────────────────────
// Rotation = overwrite an EXISTING label with a new value (same O(depth)
// dirty-path recompute as an insert). The epoch-commit-vs-N cost is in the
// timing CSV (it depends on the committed-snapshot clone, ~O(N)).

fn bench_m9_rotation(c: &mut Criterion) {
    let mut g = c.benchmark_group("M9_key_rotation");
    let serv = std::cell::RefCell::new(build_server(10_000));
    let uids = sampled_user_ids(10_000, 200);
    let ctr = std::cell::Cell::new(0u64);
    let idx = std::cell::Cell::new(0usize);
    g.throughput(Throughput::Elements(1));
    g.bench_function("rotate_existing_key_N10k", |b| {
        b.iter(|| {
            let v = ctr.get();
            ctr.set(v + 1);
            let i = idx.get();
            idx.set((i + 1) % uids.len());
            // overwrite a sampled existing user's value (a key rotation)
            serv.borrow_mut()
                .update(&uids[i], &sha256(&v.to_le_bytes()));
        });
    });
    g.finish();
}

// ── M10: VRF isolation (constant-time, N-independent) ──────────

fn bench_m10_vrf_isolation(c: &mut Criterion) {
    let mut g = c.benchmark_group("M10_vrf_isolation");
    g.sample_size(50);
    let kp = generate_vrf_keypair();
    let alpha = b"user-000000";
    let out = vrf_prove(&kp.secret, alpha);
    g.bench_function("vrf_prove", |b| {
        b.iter(|| black_box(vrf_prove(&kp.secret, alpha)));
    });
    g.bench_function("vrf_verify", |b| {
        b.iter(|| black_box(vrf_verify(&kp.public_key, alpha, &out.proof).unwrap()));
    });
    g.finish();
}

// ── M11: one full KT lookup-verification, measured at the handshake hook ──
// M11 measures one full KT signed-head lookup verification (VRF + label
// binding + prefix root + log inclusion + STH sig) invoked at the handshake
// hook. It excludes PQXDH/X3DH, network transfer, and session-state work.
// no_kt is the existing identity-key hash check, a local comparison floor —
// not a measured end-to-end handshake baseline.
//
// The committed CSV key stays `M11_handshake_overhead` because the
// committed corpus is published under it; the name is the metric's, not a claim.

fn bench_m11_overhead(c: &mut Criterion) {
    let mut g = c.benchmark_group("M11_handshake_overhead");
    g.sample_size(50);
    let mut server = build_server(10_000);
    let sth = server.commit_epoch();
    let pk = server.vrf_public_key().clone();
    let vk = server.sth_verifying_key();
    let their_key = sha256(b"their-identity-key");
    let uids = sampled_user_ids(10_000, 200);
    let results: Vec<_> = uids
        .iter()
        .map(|u| {
            let result = server.search_by_user_id(u);
            assert_eq!(result.tree_head, sth.root, "STH must match search head");
            result
        })
        .collect();

    // no_kt: no-KT baseline (non-KT identity check ≈ a hash) — anchors "≈0 added".
    g.bench_function("no_kt_baseline", |b| {
        b.iter(|| black_box(sha256(&their_key)));
    });
    // M11: one full signed-head lookup verification invoked at the handshake hook (sampled users).
    let idx = std::cell::Cell::new(0usize);
    g.bench_function("M11_kt_overhead_per_handshake", |b| {
        b.iter(|| {
            let i = idx.get();
            idx.set((i + 1) % results.len());
            let root = verify_search_result(&pk, &uids[i], &results[i]).expect("verifies");
            black_box(root);
            black_box(sth.verify(&vk));
        });
    });
    g.finish();
}

// ── M12: Auditor cost (epoch audit + cross-vantage fork detection) ──
// The equivocation machinery, measured. Two operations:
//   audit_epoch = STH sig verify + append-only consistency proof (gen + verify),
//                 ~O(log N) — the honest per-epoch auditor cost.
//   detect_fork = STH sig verify + linear scan of observed heads (this
//                 benchmark seeds a single head) — the cross-vantage check that
//                 turns two validly-signed conflicting heads into publishable
//                 evidence of a split-world.
// audit_epoch is &mut self / stateful (it pushes the head to `observed`); the
// push is O(1), so to keep the timed work stable and read-only we exercise its
// exact cryptographic body. detect_fork uses the real API against a genuine
// equivocating head produced by `KTServer::equivocate`.

fn bench_m12_auditor(c: &mut Criterion) {
    let mut g = c.benchmark_group("M12_auditor");
    g.sample_size(50);

    for &n in &[1_000usize, 10_000] {
        let epochs = 50;
        let mut server = build_server_epochs(n, epochs);
        let vk = server.sth_verifying_key();
        let old_size = (server.log_size() / 2) as u64;
        let old_root = server.log_root_at(old_size as usize);
        let new_root = server.log_root();
        let sth = server
            .current_sth()
            .expect("server has committed epochs")
            .clone();

        // audit_epoch body: sig verify + consistency proof (gen + verify).
        g.bench_with_input(BenchmarkId::new("audit_epoch", n), &n, |b, _| {
            b.iter(|| {
                black_box(sth.verify(&vk));
                let proof = server.windowed_consistency_proof(old_size);
                black_box(MerkleLog::verify_consistency(&proof, &old_root, &new_root));
            });
        });

        // detect_fork (real API): seed the auditor with the honest head, then
        // equivocate (a validly-signed conflicting head) and time the detection.
        let mut auditor = Auditor::new(vk);
        auditor.audit_epoch(&server).expect("clean baseline audit");
        let forked = server
            .equivocate(sha256(b"mallory-fork-root"))
            .expect("forked head (epoch already committed)");
        g.bench_with_input(BenchmarkId::new("detect_fork", n), &n, |b, _| {
            b.iter(|| {
                black_box(auditor.detect_fork(&forked));
            });
        });
    }

    g.finish();
}

// ── Timing CSV (median / p95 / mean / 95% CI) ──────────────────
// Criterion keeps CIs only in its HTML; this dumps the headline client/server
// timings to a committed, reproducible CSV with a 95% confidence half-width OF
// THE MEAN (normal approximation, 1.96*s/sqrt(n)). It quantifies the precision
// of the mean and says nothing about the median recorded beside it — do not
// read the two together. Gated by KT_SKIP_CSV like the size CSV.

fn ci95_halfwidth(v: &[f64]) -> f64 {
    let n = v.len() as f64;
    if n < 2.0 {
        return 0.0;
    }
    let mean = v.iter().sum::<f64>() / n;
    let var = v.iter().map(|x| (x - mean) * (x - mean)).sum::<f64>() / (n - 1.0);
    1.96 * (var / n).sqrt() // normal approx; n is large (≥1000)
}

fn time_us<F: FnMut()>(samples: usize, mut f: F) -> Vec<f64> {
    let mut v = Vec::with_capacity(samples);
    for _ in 0..samples {
        let t = std::time::Instant::now();
        f();
        v.push(t.elapsed().as_secs_f64() * 1e6);
    }
    v
}

fn emit_timing(f: &mut fs::File, metric: &str, base: &str, n: usize, samples: &[f64]) {
    let s = sorted(samples.to_vec());
    let mean = s.iter().sum::<f64>() / s.len() as f64;
    writeln!(
        f,
        "{},{},{},median,{:.3},us",
        metric,
        base,
        n,
        percentile(&s, 0.5)
    )
    .unwrap();
    writeln!(
        f,
        "{},{},{},p95,{:.3},us",
        metric,
        base,
        n,
        percentile(&s, 0.95)
    )
    .unwrap();
    writeln!(f, "{},{},{},mean,{:.3},us", metric, base, n, mean).unwrap();
    writeln!(
        f,
        "{},{},{},ci95_halfwidth,{:.3},us",
        metric,
        base,
        n,
        ci95_halfwidth(samples)
    )
    .unwrap();
}

fn write_timing_csv(_c: &mut Criterion) {
    if std::env::var("KT_SKIP_CSV")
        .map(|v| v == "1")
        .unwrap_or(false)
    {
        eprintln!("KT_SKIP_CSV=1 — skipping timing CSV generation");
        return;
    }
    print_phase_head("timing CSV");
    let _ = fs::create_dir_all("results");
    let mut f = fs::File::create("results/rust_benchmark_timings.csv").unwrap();
    writeln!(f, "metric,baseline,N,stat,value,unit").unwrap();

    let samples = 2_000usize;
    for &n in &[1_000usize, 10_000] {
        eprintln!("timings: building N={} ...", n);
        let mut server = build_server(n);
        let sth = server.commit_epoch();
        let pk = server.vrf_public_key().clone();
        let vk = server.sth_verifying_key();

        // Sampled lookup targets (seeded StdRng(42), mirrors M7): per-path
        // cost is data-dependent in the path-compressed tree, so every timed
        // loop below cycles through K sampled users rather than re-timing one
        // fixed label's path 2,000 times (SAMPLING RULE in the header).
        let k = 200usize;
        let uids = sampled_user_ids(n, k);
        let results: Vec<_> = uids.iter().map(|u| server.search_by_user_id(u)).collect();
        let prefixes: Vec<_> = results.iter().map(|r| r.prefix_proof.clone()).collect();
        let vrf_proofs: Vec<_> = results
            .iter()
            .map(|r| r.vrf_proof.expect("search carries VRF proof"))
            .collect();

        // M2: server-side proof generation (full search), sampled users.
        let idx = std::cell::Cell::new(0usize);
        emit_timing(
            &mut f,
            "M2_search_gen",
            "dual_index",
            n,
            &time_us(samples, || {
                let i = idx.get();
                idx.set((i + 1) % k);
                black_box(server.search_by_user_id(&uids[i]).value);
            }),
        );
        // M3: client-side verification pieces + total, sampled users.
        let idx = std::cell::Cell::new(0usize);
        emit_timing(
            &mut f,
            "M3_prefix_verify",
            "dual_index",
            n,
            &time_us(samples, || {
                let i = idx.get();
                idx.set((i + 1) % k);
                black_box(SparsePrefixTree::recompute_root(&prefixes[i]));
            }),
        );
        let idx = std::cell::Cell::new(0usize);
        emit_timing(
            &mut f,
            "M3_vrf_verify",
            "dual_index",
            n,
            &time_us(samples, || {
                let i = idx.get();
                idx.set((i + 1) % k);
                black_box(vrf_verify(&pk, &uids[i], &vrf_proofs[i]).unwrap());
            }),
        );
        let idx = std::cell::Cell::new(0usize);
        let full = time_us(samples, || {
            let i = idx.get();
            idx.set((i + 1) % k);
            black_box(verify_search_result(&pk, &uids[i], &results[i]).unwrap());
            black_box(sth.verify(&vk));
        });
        emit_timing(&mut f, "M3_full_client_verify", "windowed", n, &full);
        // M11: same op, framed as the KT lookup-verification cost at the handshake hook.
        emit_timing(&mut f, "M11_handshake_overhead", "windowed", n, &full);

        // M9: rotation (overwrite existing key) on a separate growing-free
        // server, cycling sampled users so the rotation path varies too.
        let serv = std::cell::RefCell::new(build_server(n));
        let ctr = std::cell::Cell::new(0u64);
        let idx = std::cell::Cell::new(0usize);
        emit_timing(
            &mut f,
            "M9_rotation",
            "dual_index",
            n,
            &time_us(samples, || {
                let v = ctr.get();
                ctr.set(v + 1);
                let i = idx.get();
                idx.set((i + 1) % k);
                serv.borrow_mut()
                    .update(&uids[i], &sha256(&v.to_le_bytes()));
            }),
        );
        // M9: epoch-commit cost — overwrite one fixed key then commit (stable
        // tree size N) so we isolate commit (~O(N) snapshot clone + sign).
        {
            let mut s = build_server(n);
            emit_timing(
                &mut f,
                "M9_epoch_commit",
                "windowed",
                n,
                &time_us(200, || {
                    s.update(b"pending-key", &sha256(b"pending-key"));
                    black_box(s.commit_epoch());
                }),
            );
        }
    }

    // M10: VRF isolation (constant-time; report at N=0 to mark N-independence).
    {
        let kp = generate_vrf_keypair();
        let out = vrf_prove(&kp.secret, b"user-000000");
        emit_timing(
            &mut f,
            "M10_vrf_prove",
            "—",
            0,
            &time_us(2_000, || {
                black_box(vrf_prove(&kp.secret, b"user-000000"));
            }),
        );
        emit_timing(
            &mut f,
            "M10_vrf_verify",
            "—",
            0,
            &time_us(2_000, || {
                black_box(vrf_verify(&kp.public_key, b"user-000000", &out.proof).unwrap());
            }),
        );
    }

    // M5: marginal unverified warning-slot read (derive labels + warning
    // lookup), clean
    // state, as a DISTRIBUTION over 1,000 sampled conversations (each of the
    // 2,000 iterations reads the next conversation's warning slot). The
    // marginal read is data-dependent: derivation is pure HKDF (~1–3 µs), but
    // a queried path whose co-path holds a shallow compressed-leaf sibling
    // pays up to ~256 hashes in `subtree_hash` (~50 µs). The median is the
    // typical-case figure; the p95 carries the compressed-leaf tail. A single
    // fixed label (the old alice/bob pair) is NOT a defensible estimate —
    // re-seeding relocates every label and changes the number arbitrarily.
    {
        let mut server = build_server(1_000);
        let convs = register_bench_conversations(&mut server, 1_000);
        server.commit_epoch();
        let idx = std::cell::Cell::new(0usize);
        emit_timing(
            &mut f,
            "M5_detection",
            "dual_index",
            1_000,
            &time_us(2_000, || {
                let i = idx.get();
                idx.set((i + 1) % convs.len());
                let cv = &convs[i];
                let labels = derive_dual_index_labels(&cv.ss, &cv.id_a, &cv.id_b);
                black_box(server.search(&labels.label_warning).value.is_some());
            }),
        );
    }

    // M8: latency-derived single-thread operation rate. We record the latency of one op (µs); the
    // report converts to elements/second as ops/s = 1e6 / median_us.
    {
        let n = 10_000usize;
        // Lookup throughput: full server-side search at fixed N (tree does not
        // grow), cycling sampled users (SAMPLING RULE).
        let mut server = build_server(n);
        server.commit_epoch();
        let uids = sampled_user_ids(n, 200);
        let idx = std::cell::Cell::new(0usize);
        emit_timing(
            &mut f,
            "M8_lookup",
            "dual_index",
            n,
            &time_us(2_000, || {
                let i = idx.get();
                idx.set((i + 1) % uids.len());
                black_box(server.search_by_user_id(&uids[i]).value);
            }),
        );
        // Update throughput: insert UNIQUE keys, so the tree grows one leaf per op.
        let mut s = build_server(n);
        let ctr = std::cell::Cell::new(0u64);
        emit_timing(
            &mut f,
            "M8_update",
            "dual_index",
            n,
            &time_us(2_000, || {
                let v = ctr.get();
                ctr.set(v + 1);
                s.update(&sha256(&v.to_le_bytes()), &sha256(b"pk"));
            }),
        );
    }

    // M12: auditor cost — the local signature + consistency-proof kernel and the
    // cross-vantage fork-detection check (sig verify + linear observed-head
    // scan; a single head is seeded here).
    {
        let n = 10_000usize;
        let epochs = 50;
        let mut server = build_server_epochs(n, epochs);
        let vk = server.sth_verifying_key();
        let old_size = (server.log_size() / 2) as u64;
        let old_root = server.log_root_at(old_size as usize);
        let new_root = server.log_root();
        let sth = server.current_sth().expect("committed epochs").clone();
        emit_timing(
            &mut f,
            "M12_audit_epoch",
            "windowed",
            n,
            &time_us(2_000, || {
                black_box(sth.verify(&vk));
                let proof = server.windowed_consistency_proof(old_size);
                black_box(MerkleLog::verify_consistency(&proof, &old_root, &new_root));
            }),
        );
        let mut auditor = Auditor::new(vk);
        auditor.audit_epoch(&server).expect("clean baseline audit");
        let forked = server
            .equivocate(sha256(b"mallory-fork-root"))
            .expect("forked head");
        emit_timing(
            &mut f,
            "M12_detect_fork",
            "windowed",
            n,
            &time_us(2_000, || {
                black_box(auditor.detect_fork(&forked));
            }),
        );
    }

    // M13: per-epoch client verify on each mode (session dual-index vs
    // continuous CEA). Same operations bench_m13_modes times under Criterion,
    // emitted here so the Appendix E M13 medians reproduce from the CSV.
    // N-suffixed baseline mirrors the bench; K sampled conversations/chains are
    // cycled one per timed iteration (SAMPLING RULE).
    {
        use duet::cea::{cea_register, verify_epoch, CeaChain, CeaRegisterOutcome};
        let n = 10_000usize;
        let k = 200usize;

        // Session (dual-index): sampled conversations, one lookup verify each.
        // Precompute the lookup label AND the expected value in setup (as
        // the continuous path does for its label/fingerprint), so the timed
        // body of BOTH modes is exactly "search + label-bound proof verify +
        // expected-value compare" — label derivation (a fixed sub-µs
        // HKDF/hash) is done once in setup and excluded from both, and the
        // session body performs the logged-vs-expected key comparison (the
        // detectMitm check) exactly as continuous performs verify_epoch's
        // fingerprint comparison, making the two medians apples-to-apples.
        let mut server = build_server(n);
        let convs = register_bench_conversations(&mut server, k);
        server.commit_epoch();
        let sess_lookups: Vec<_> = convs
            .iter()
            .map(|cv| {
                let label = derive_dual_index_labels(&cv.ss, &cv.id_a, &cv.id_b).label_lookup;
                (label, sha256(&cv.id_a)) // expected value registered in setup
            })
            .collect();
        for (l, exp) in &sess_lookups {
            let r = server.search(l);
            verify_search_result_raw_for(l, &r).expect("session lookup must verify");
            assert_eq!(r.value.as_deref(), Some(exp.as_slice()));
        }
        let idx = std::cell::Cell::new(0usize);
        emit_timing(
            &mut f,
            "M13_session_verify",
            "dual_index",
            n,
            &time_us(samples, || {
                let i = idx.get();
                idx.set((i + 1) % sess_lookups.len());
                let (l, exp) = &sess_lookups[i];
                let res = server.search(l);
                black_box(verify_search_result_raw_for(l, &res).is_ok());
                black_box(res.value.as_deref() == Some(exp.as_slice()));
            }),
        );

        // Continuous (CEA): each chain registers one epoch through the
        // ACKA path (`cea_register`: sender pre-post check -> write-once ->
        // commit -> confirm the read-back -> advance ONLY after the confirmed
        // write, ACKA Fig. 8), then the per-epoch client verify is timed. The
        // timed body is the label-bound proof check plus the fingerprint
        // comparison -- exactly the work `cea_verify` does before its (untimed,
        // single-hash) state advance. The folded SECRET (`dh_secret`, ACKA's
        // `I`/`ck`) and the authenticated PUBLIC key (ACKA's `T`) are
        // DISTINCT per-epoch values, not one key reused for both; both are
        // simulated stand-ins for the real ratchet material (disclosed in the
        // thesis).
        let mut chains: Vec<([u8; 32], [u8; 32])> = Vec::with_capacity(k);
        for i in 0..k {
            let ss = sha256(format!("m13-cea-ss-{:06}", i).as_bytes());
            let id_a = format!("cea-a-{:06}", i).into_bytes();
            let id_b = format!("cea-b-{:06}", i).into_bytes();
            let mut chain = CeaChain::new(&ss, &id_a, &id_b);
            let dh_secret = sha256(format!("m13-epoch-1-dh-secret-{:06}", i).as_bytes());
            let epk = sha256(format!("m13-epoch-1-dh-pub-{:06}", i).as_bytes());
            // Capture the epoch being registered: `cea_register` advances the
            // chain only AFTER the confirmed write, so read label/fp first.
            let label = chain.label(&id_a, &id_b);
            let fp = chain.fingerprint(&id_a, &id_b, &epk);
            let outcome = cea_register(&mut chain, &mut server, &id_a, &id_b, &dh_secret, &epk);
            assert_eq!(
                outcome,
                CeaRegisterOutcome::Registered,
                "M13: cea_register must succeed on a fresh epoch label"
            );
            chains.push((label, fp));
        }
        let idx = std::cell::Cell::new(0usize);
        emit_timing(
            &mut f,
            "M13_continuous_verify",
            "continuous",
            n,
            &time_us(samples, || {
                let i = idx.get();
                idx.set((i + 1) % chains.len());
                let (label, fp) = &chains[i];
                let res = server.search(label);
                black_box(verify_search_result_raw_for(label, &res).is_ok());
                black_box(verify_epoch(res.value.as_deref(), fp));
            }),
        );
    }

    // M4: catch-up GENERATION time (windowed vs sequential) so the thesis M4
    // timing quotes reproduce from this CSV rather than only from Criterion
    // estimates. The N column carries the window W; the directory is fixed at
    // N=1,000 and the timed operations are identical to the
    // M4_catchup_cost Criterion group's.
    {
        let n = 1_000usize;
        for &w in W_VALUES {
            let total_epochs = w + 10;
            let server = build_server_epochs(n, total_epochs);
            let from_epoch = (total_epochs - w) as u64;
            emit_timing(
                &mut f,
                "M4_catchup_gen",
                "sequential",
                w,
                &time_us(samples, || {
                    for e in 0..w {
                        let from = (from_epoch as usize) + e;
                        if from < server.log_size() {
                            black_box(server.windowed_consistency_proof(from as u64));
                        }
                    }
                }),
            );
            emit_timing(
                &mut f,
                "M4_catchup_gen",
                "windowed",
                w,
                &time_us(samples, || {
                    black_box(server.windowed_consistency_proof(from_epoch));
                }),
            );
        }
    }

    eprintln!("timing CSV written to results/rust_benchmark_timings.csv");
    black_box(());
}

// ── M13: session (dual-index) vs continuous (CEA) mode ─────────
// The cost of ACKA continuous detection. Continuous mode writes ONE
// log entry per ratchet epoch; session (dual-index) mode writes one per
// signed-pre-key rotation. We (a) time one per-epoch client verify on each
// path and (b) emit the write-count growth over a conversation to
// results/rust_benchmark_m13.csv. Honest caveat (thesis): real ratchet cadence
// is message-driven, so continuous-mode writes are an UNDER-count here.

fn bench_m13_modes(c: &mut Criterion) {
    use duet::cea::{cea_register, verify_epoch, CeaChain, CeaRegisterOutcome};

    let mut g = c.benchmark_group("M13_modes");
    g.sample_size(30);

    let n = 10_000usize;
    let mut server = build_server(n);
    // Session (dual-index): K sampled conversations, cycling one per timed
    // iteration (SAMPLING RULE: per-path verify cost is data-dependent, so a
    // single fixed alice/bob label is not a defensible estimate).
    let convs = register_bench_conversations(&mut server, 200);
    server.commit_epoch();
    {
        // Precompute the lookup label AND expected value (continuous
        // precomputes label/fp too), so the timed body of both modes is exactly
        // "search + label-bound verify + expected-value compare" — the session
        // body performs the logged-vs-expected key comparison (detectMitm)
        // exactly as continuous performs verify_epoch's fingerprint compare.
        let sess_lookups: Vec<_> = convs
            .iter()
            .map(|cv| {
                let label = derive_dual_index_labels(&cv.ss, &cv.id_a, &cv.id_b).label_lookup;
                (label, sha256(&cv.id_a)) // expected value registered in setup
            })
            .collect();
        for (l, exp) in &sess_lookups {
            let r = server.search(l);
            verify_search_result_raw_for(l, &r).expect("session lookup must verify");
            assert_eq!(r.value.as_deref(), Some(exp.as_slice()));
        }
        let idx = std::cell::Cell::new(0usize);
        g.bench_function("session_lookup_verify", |b| {
            b.iter(|| {
                let i = idx.get();
                idx.set((i + 1) % sess_lookups.len());
                let (l, exp) = &sess_lookups[i];
                let res = server.search(l);
                black_box(verify_search_result_raw_for(l, &res).is_ok());
                black_box(res.value.as_deref() == Some(exp.as_slice()));
            });
        });
    }

    // Continuous (CEA): each chain registers one epoch through the
    // ACKA path (`cea_register`: pre-post check -> write-once -> commit ->
    // confirm -> advance only after the confirmed write, ACKA Fig. 8); the
    // per-epoch client verify (label-bound proof check + fingerprint compare,
    // the work `cea_verify` times before its state advance) is timed cycling
    // across the chains. The folded SECRET (`dh_secret`) and authenticated
    // PUBLIC ratchet key (ACKA's `T`) are DISTINCT per-epoch stand-ins for ACKA's I and T;
    // the ratchet is simulated (disclosed in the thesis).
    {
        let k = 200usize;
        let mut chains: Vec<([u8; 32], [u8; 32])> = Vec::with_capacity(k);
        for i in 0..k {
            let ss = sha256(format!("m13-cea-ss-{:06}", i).as_bytes());
            let id_a = format!("cea-a-{:06}", i).into_bytes();
            let id_b = format!("cea-b-{:06}", i).into_bytes();
            let mut chain = CeaChain::new(&ss, &id_a, &id_b);
            let dh_secret = sha256(format!("m13-epoch-1-dh-secret-{:06}", i).as_bytes());
            let epk = sha256(format!("m13-epoch-1-dh-pub-{:06}", i).as_bytes());
            let label = chain.label(&id_a, &id_b);
            let fp = chain.fingerprint(&id_a, &id_b, &epk);
            let outcome = cea_register(&mut chain, &mut server, &id_a, &id_b, &dh_secret, &epk);
            assert_eq!(
                outcome,
                CeaRegisterOutcome::Registered,
                "M13: cea_register must succeed on a fresh epoch label"
            );
            chains.push((label, fp));
        }
        let idx = std::cell::Cell::new(0usize);
        g.bench_function("continuous_epoch_verify", |b| {
            b.iter(|| {
                let i = idx.get();
                idx.set((i + 1) % chains.len());
                let (label, fp) = &chains[i];
                let res = server.search(label);
                black_box(verify_search_result_raw_for(label, &res).is_ok());
                black_box(verify_epoch(res.value.as_deref(), fp));
            });
        });
    }
    g.finish();

    // Computed: write-count growth over a conversation of E epochs.
    // Hourly-epoch units; signed-pre-key rotation every 30 days ⇒ R = 720.
    if std::env::var("KT_SKIP_CSV")
        .map(|v| v == "1")
        .unwrap_or(false)
    {
        return;
    }
    let _ = fs::create_dir_all("results");
    let mut f = fs::File::create("results/rust_benchmark_m13.csv").unwrap();
    writeln!(f, "metric,mode,E_epochs,R_rotation,writes,unit").unwrap();
    let r_rot = 720usize;
    for &e in &[24usize, 168, 720, 4320] {
        let cont = e; // one write per ratchet epoch
        let sess = e.div_ceil(r_rot).max(1); // one per pre-key rotation
        writeln!(f, "M13,continuous,{},{},{},writes", e, r_rot, cont).unwrap();
        writeln!(f, "M13,session,{},{},{},writes", e, r_rot, sess).unwrap();
        writeln!(
            f,
            "M13,ratio,{},{},{:.1},x",
            e,
            r_rot,
            cont as f64 / sess as f64
        )
        .unwrap();
    }
    eprintln!("M13 write-count CSV → results/rust_benchmark_m13.csv");
}

// ── Criterion Entry ────────────────────────────────────────────

criterion_group!(
    benches,
    bench_m2_proof_generation,
    bench_m3_proof_verification,
    bench_m4_catchup_cost,
    bench_m5_mitm_detection,
    bench_m8_throughput,
    bench_m9_rotation,
    bench_m10_vrf_isolation,
    bench_m11_overhead,
    bench_m12_auditor,
    bench_m13_modes,
    write_csv,
    write_timing_csv,
    // M7 LAST on purpose: it is the heaviest (10^7 build ≈ 41 min, ≈17 GB RSS).
    // If it OOMs/crashes, every other group + both CSVs are already written.
    bench_m7_scale_verification,
);
criterion_main!(benches);
